Page({
  data: {
    cities: []
  },
  onLoad: function() {
    console.log("message page onload")
  },
  onHide: function() {
    console.log("message page onhide")
  },
  onShow: function() {

  },

});