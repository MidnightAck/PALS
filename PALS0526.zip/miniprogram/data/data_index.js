/**
 * Created by Rebecca_Han on 16/10/26.
 */
module.exports = {

}

var index= {
    "id": 1,
        "data": [
        {
            "question_id": 1,
            "answer_id": 3,
            "feed_source_id": 23,
            "feed_source_name": "郭德纲",
            "feed_source_txt": " 发布了组队",
            "feed_source_img": "../../images/icon1.jpeg",
            "question": "约洗澡",
            "answer_ctnt": "不想和于谦搭档了",
            "good_num": "5",
            "comment_num": "18"
        },
          {
            "question_id": 2,
            "answer_id": 25,
            "feed_source_id": 24,
            "feed_source_name": "杨超越",
            "feed_source_txt": "发布了组队",
            "feed_source_img": "../../images/icon8.jpg",
            "question": "约唱K",
            "answer_ctnt": "只要刘姓程序员",
            "good_num": "1",
            "comment_num": "118"
          },
       

    ]

}

module.exports.index = index;